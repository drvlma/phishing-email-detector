function onEdit(e) {
  var sheet = e.source.getActiveSheet();
  var editedRow = e.range.getRow();

  if (editedRow === 1) return; // skip header

  var linkCell = sheet.getRange(editedRow, 4).getValue(); // Contains Suspicious Link
  var urgencyCell = sheet.getRange(editedRow, 5).getValue(); // Urgent Language
  var matchCell = sheet.getRange(editedRow, 6).getValue(); // Sender Name Match

  var flagged = "No";

  if (linkCell === "Y" || urgencyCell === "Y" || matchCell === "N") {
    flagged = "Yes";
  }

  sheet.getRange(editedRow, 7).setValue(flagged); // Write result in "Flagged as Phishing?"
}